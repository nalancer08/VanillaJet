function Dipper(options, shared) {

	let path = require('path');

	this.options = options;
	this.shared = shared;
	this.metas = [];
	this.site_title = shared.site_name;
	this.page_title = this.site_title;
	this.description = shared.description;
	this.fbAppId = shared.fbAppId;
	this.base_dir = path.join(process.cwd(), '/');
	
	// Dirs
	this.dirs = {

		'images'  : '/public/images/',
		'scripts' : '/public/scripts/',
		'styles'  : '/public/styles/',
		'fonts'   : '/public/fonts/',
		'anims'   : '/public/anims/'
	}

	// -- Static content
	this.scripts = [];
	this.styles = [];
	this.anims = [];
	this.enqueued_scripts = [];
	this.enqueued_styles = [];

	// -- Base scripts
	let vanillaJetJson = this.openJsonFile('vanillaJet.package.json');
	if (vanillaJetJson) {
		let coreDependencies = vanillaJetJson.coreDependencies;
		for (let key in coreDependencies) {
			// Fingerprint local core dependencies exactly like every other
			// registered asset (?v=size-mtime → immutable, and a NEW url on
			// every deploy). Registered bare, they fell under the
			// `static_cache_max_age` bucket: clients kept a stale domain/api/
			// utils for up to that TTL while the fingerprinted view bundle
			// updated instantly — mismatched generations in production
			// ("Domain.product.isEdoMexAddress is not a function").
			// versionedUrl leaves external urls and missing files untouched.
			this.registerScript(key, this.versionedUrl(coreDependencies[key]));
		}
	}
}

Dipper.prototype.getPageTitle = function() {
	return this.page_title;
}

Dipper.prototype.getSiteTitle = function() {
	return this.site_title;
}

Dipper.prototype.getDescription = function() {
	return this.description;
}

Dipper.prototype.getFbAppId = function() {
	return this.fbAppId;
}

Dipper.prototype.addMeta = function({name, content, attribute}) {

	let obj = this;
	attribute = attribute || 'name';
	content = content || '';
	let meta = [];
		meta['name'] = name;
		meta['content'] = content;
		meta['attribute'] = attribute;
	obj.metas[name] = meta;
}

Dipper.prototype.metaTags = function() {

	let obj = this;
	let _ = require('underscore');
	let stringMeta = '';

	let keys = Object.keys(obj.metas);
	_.each(keys, function(key) {
		
		let name = obj.metas[key]['name'],
			content = obj.metas[key]['content'],
			attribute = obj.metas[key]['attribute'];

    stringMeta += obj.metas[key]['content'] != '' ? 
			`<meta ${attribute}="${name}" content="${content}">\n\t` :
			`<meta ${name}="${attribute}">\n\t`;
	});
	return stringMeta;			
}

Dipper.prototype.img = function(filename) {
	let dir = this.getDir('images', false);
	return this.urlTo(dir + filename);
}

Dipper.prototype.script = function(filename) {
	let dir = this.getDir('scripts', false);
	return this.versionedUrl(dir + filename);
}

Dipper.prototype.style = function(filename) {
	let dir = this.getDir('styles', false);
	return this.versionedUrl(dir + filename);;
}

Dipper.prototype.pdf = function(filename) {

	let dir = '/assets/pdf/';
	return this.urlTo(dir + filename);
}

Dipper.prototype.getDir = function(dir, full) {
	
	let obj = this;
	full = (full == undefined) ? true : full;

	if ( obj.dirs[dir] != undefined ) {
		return (full == true ? obj.baseDir(obj.dirs[dir]) : obj.dirs[dir]);
	}
	return false;
}

Dipper.prototype.baseDir = function(path) {
	path = path || '';
	return this.base_dir + path;
}

Dipper.prototype.urlTo = function (route) {
  if (/^(?:[a-z][a-z0-9+.-]*:)?\/\//i.test(route)) return route;
  return '/' + route.replace(/^\/+/, '');
};

Dipper.prototype.versionedUrl = function(route) {
	const fs = require('fs');
	const path = require('path');
	const normalizedUrl = this.urlTo(route);

	// External URLs should remain untouched.
	if (/^(?:[a-z][a-z0-9+.-]*:)?\/\//i.test(normalizedUrl)) {
		return normalizedUrl;
	}

	try {
		const filePath = path.join(this.processCwd(), normalizedUrl.replace(/^\//, ''));
		const stats = fs.statSync(filePath);
		if (!stats.isFile()) {
			return normalizedUrl;
		}

		const version = `${stats.size}-${Math.floor(stats.mtimeMs)}`;
		return this.appendQueryParam(normalizedUrl, 'v', version);
	} catch (err) {
		// If file does not exist yet, keep legacy behavior.
		return normalizedUrl;
	}
}

Dipper.prototype.appendQueryParam = function(url, key, value) {
	const separator = url.includes('?') ? '&' : '?';
	return `${url}${separator}${key}=${encodeURIComponent(value)}`;
}

Dipper.prototype.registerStyle = function(
	name, url, requires,
	cdn = false, async = false,
	origin = '', integrity = '') {
	
	var obj = this;
	obj.styles[name] = {
		'resource' : url,
		'requires' : requires,
		'cdn' : cdn,
		'async' : async,
		'origin' : origin,
		'integrity' : integrity
	};
}

Dipper.prototype.registerScript = function(
	name, url, requires, 
	cdn = false, async = false, defer = false,
	origin = '', integrity = '') {
	
	var obj = this;
	obj.scripts[name] = {

		'resource' : url,
		'requires' : requires,
		'cdn' : cdn,
		'async' : async,
		'defer': defer,
		'origin' : origin,
		'integrity' : integrity
	};
}

Dipper.prototype.registerAnimation = function(name, url) {
	
	let obj = this;
	obj.anims[name] = {
		'resource' : url,
		'requires' : []
	};
}

Dipper.prototype.enqueueStyle = function(name) {

	var obj = this,
		_ = require('underscore');

	if (obj.styles[name] != undefined) {
		if (obj.enqueued_styles[name] == undefined) {
			
			var item = obj.styles[name];
			_.each(item.requires, function(dep) {
				obj.enqueueStyle(dep);
			});
			obj.enqueued_styles[name] = name;
		}
	}
}

Dipper.prototype.enqueueScript = function(name) {

	var obj = this,
		_ = require('underscore');

	if (obj.scripts[name] != undefined) {
		if (obj.enqueued_scripts[name] == undefined) {

			var item = obj.scripts[name];
			_.each(item.requires, function(dep) {
				obj.enqueueScript(dep);
			});
			obj.enqueued_scripts[name] = name;
		}
	}
}

Dipper.prototype.dequeueStyle = function(name, dependencies) {

	var obj = this,
		_ = require('underscore')
		dependencies = (dependencies == undefined) ? false : dependencies;

	if (obj.styles[name] != undefined) {
		if (obj.enqueued_styles[name] != undefined) {
			var item = obj.styles[name];
			if (dependencies === true && Array.isArray(item.requires)) {
				_.each(item.requires, function(dep) {
					obj.dequeueStyle(dep);
				});
			}
			delete obj.enqueued_styles[name];
		}
	}
}

Dipper.prototype.dequeueScript = function(name, dependencies) {

	var obj = this,
		_ = require('underscore')
		dependencies = (dependencies == undefined) ? false : dependencies;

	if (obj.scripts[name] != undefined) {
		if (obj.enqueued_scripts[name] != undefined) {
			var item = obj.scripts[name];
			if (dependencies === true && Array.isArray(item.requires)) {
				_.each(item.requires, function(dep) {
					obj.dequeueScript(dep);
				});
			}
			delete obj.enqueued_scripts[name];
		}
	}
}

Dipper.prototype.includeStyle = function(style) {
			
	var obj = this;
	if (obj.styles[style]) {

		var item = obj.styles[style],
			output = '',
			//type = item['cdn'] ? "" : 'type=\"text/javascript\"',
			resource = item['resource'],
			isAsync = item['async'] ? 'preload' : 'stylesheet',
			origin = item['origin'] != '' ? ' crossorigin=\"' + item['origin'] + '\"' : '',
			integrity = item['integrity'] != '' ? ' integrity=\"' + item['integrity'] + '\"' : '';
		
		if (item['async']) {

			var a = " as=\"style\" onload=\"this.onload=null; this.rel='stylesheet'\"";
			output = '<link rel=\"' + isAsync + '\" type=\"text/css\" href=\"' + resource + '\"' + a + integrity + origin + ">";
		} else {
			output = '<link rel=\"' + isAsync + '\" type=\"text/css\" href=\"' + resource + '\"' + integrity + origin + ">";
		}
		return output + "\n";
	}
}

Dipper.prototype.includeScript = function(script) {
	
	var obj = this;
	if (obj.scripts[script]) {

		var item = obj.scripts[script],
			output = '',
			//type = item['cdn'] ? "" : 'type=\"text/javascript\"',
			resource = item['resource'],
			isAsync = item['async'] ? ' async' : '',
			// Honor a per-script defer flag, or the global settings.profile.defer_scripts
			// (applied to non-async scripts so they don't block parsing; order preserved).
			defer = (item['defer'] || (obj.options && obj.options.defer_scripts && !item['async'])) ? ' defer' : '',
			origin = item['origin'] != '' ? ' crossorigin=\"' + item['origin'] + '\"' : '',
			integrity = item['integrity'] != '' ? ' integrity=\"' + item['integrity'] + '\"' : '';
		
		output = '<script src=\"' + resource + '\"' + defer + isAsync + integrity + origin + '></script>';
		//console.log(output);
		return output + "\n";
	}
}

Dipper.prototype.includeAnimation = function(anim) {

	let obj = this;
	if (obj.anims[anim]) {

		let item = obj.anims[anim],
			output = '',
			resource = item['resource'];

		if (!/^(https?:\/\/|\/\/)/.test(resource)) {
			let jsonAnim = obj.openJsonFile(resource);
			output = `var ${item['name']} = ${JSON.stringify(jsonAnim)};`;
		}
		return output + "\n";
	}
}

Dipper.prototype.includeStyles = function() {
	
	var obj = this,
		_ = require('underscore')
		stylesString = '',
		keys = Object.keys(obj.enqueued_styles);

	_.each(keys, function(style) {
		stylesString += obj.includeStyle(style);
	});

	//console.log(stylesString);
	//$site->executeHook('core.includeStyles');
	return stylesString;
}

Dipper.prototype.includeScripts = function () {
			
	var obj = this,
		_ = require('underscore')
		scriptsString = '',
		keys = Object.keys(obj.enqueued_scripts);

	_.each(keys, function(script) {
		scriptsString += obj.includeScript(script);
	});
	return scriptsString;
}

Dipper.prototype.includeAnimations = function() {

	let obj = this,
		_ = require('underscore'),
		animsString = '',
		keys = Object.keys(obj.anims);

	_.each(keys, function(anim) {
		animsString += obj.includeAnimation(anim);
	});
	let baseAnimsString = `<script>'${animsString}'</script>`;
	return baseAnimsString;
}

Dipper.prototype.includeManifest = function() {

	var obj = this,
		url = obj.urlTo('/public/manifest.json'),
		tagString = '<link rel=\"manifest\" href=\"' + url + '\">';
	return tagString;
}

/**
 * Inline service-worker teardown. VanillaJet no longer ships a caching
 * service worker (removed in 1.7.0 after production incidents where
 * not-yet-updated workers kept answering fresh HTML with a previous
 * generation's bundles), so any worker found on the origin is a leftover
 * that must go.
 *
 * This snippet is the page-side healing channel: it lives in the rendered
 * HTML (served with no-cache, the one asset a stale worker never poisons),
 * unregisters every registration, wipes Cache Storage, and — only when the
 * page was actually painted through a worker — reloads once so document and
 * assets come from the same (network) generation. A sessionStorage guard
 * makes the reload impossible to repeat within the tab session, so a client
 * whose worker refuses to die can never enter a reload loop.
 *
 * It complements the kill-switch published at /sw.js (scripts/generate_sw.js),
 * which reaches clients through the other channel a zombie cannot poison:
 * the service-worker script byte-diff on its update check.
 */
Dipper.prototype.includeServiceWorker = function() {

	return `
		<script>
			(function () {
				if (!('serviceWorker' in navigator)) { return; }
				var controlled = Boolean(navigator.serviceWorker.controller);
				var guard = 'vj-sw-teardown-reload';
				navigator.serviceWorker.getRegistrations().then(function (registrations) {
					return Promise.all(registrations.map(function (registration) {
						return registration.unregister();
					}));
				}).then(function () {
					if (!('caches' in window)) { return; }
					return caches.keys().then(function (keys) {
						return Promise.all(keys.map(function (key) { return caches.delete(key); }));
					});
				}).then(function () {
					if (!controlled) {
						try { sessionStorage.removeItem(guard); } catch (error) { /* storage blocked */ }
						return;
					}
					var alreadyReloaded = null;
					try { alreadyReloaded = sessionStorage.getItem(guard); } catch (error) { return; }
					if (alreadyReloaded) { return; }
					// If the guard cannot be persisted (blocked storage), skip the
					// reload: healing falls back to the /sw.js kill-switch rather
					// than risking a loop.
					try { sessionStorage.setItem(guard, '1'); } catch (error) { return; }
					location.reload();
				}).catch(function (error) { console.error(error); });
			})();
		</script>`;
}

/**
 * Setup Sentry for error reporting on production and qa environments.
 */
Dipper.prototype.includeSentry = function() {

	const obj = this;

	// Falllback report error function on development
	if (obj.shared.environment === 'development') {
		return `
			<script>
				function reportError(message, data = {}) {
					console.log(message, data);
				}
			</script>`;
	}

	const releaseString = (typeof process.env.SENTRY_RELEASE === 'undefined')
		? ''
		: `<script> var SENTRY_RELEASE = '${ process.env.SENTRY_RELEASE }'; </script>`;

	const tagString = `
		<script
			src="https://browser.sentry-cdn.com/${ obj.shared.sentry.bundleVersion }/bundle.tracing.replay.min.js"
			integrity="${ obj.shared.sentry.bundleSha }"
			crossorigin="anonymous"
		></script>`;

	const loadString = `
		<script>
			if (window.Sentry) {
				Sentry.init({
					dsn: '${ obj.shared.sentry.dsn_js }',
					environment: '${ obj.shared.environment }',
					integrations: [new Sentry.BrowserTracing(), new Sentry.Replay()],
					sampleRate: ${ obj.shared.sentry.sampleRate },
					tracesSampleRate: ${ obj.shared.sentry.tracesSampleRate }
				});

				function reportError(message, data = {} ) {
					Sentry.captureException(new Error(message), { extra: data });
				}
			} else {
				function reportError(message, data = {}) {
					console.log(message, data);
				}
			}
		</script>`;

	return releaseString + tagString + loadString;
}

Dipper.prototype.getStyles = function() {

	var obj = this;
	return obj.styles;
}

Dipper.prototype.getScripts = function() {
	
	var obj = this;
	return obj.scripts;
}

Dipper.prototype.template = function(template, id, templates_dir, params) {

	var obj = this,
		fs = require('fs'),
		path = require('path'),
		templates_dir = (templates_dir == undefined) ? 'assets/templates/' : templates_dir,
		params = params || [],
		dir = path.join(process.cwd(), templates_dir),
		templateString = '<script type=\"text/template\" id=\"' + id + '\">';

	fs.exists(dir, function(exists) {

    	if (exists) {

    		var tempTemplate = template + '.html';
    		if (fs.statSync(dir).isDirectory()) dir += tempTemplate;
			
			fs.readFile(dir, "binary", function(err, file) {

		  		if (err) {
		  			
		  			templateString = '<script type=\"text/template\" id=\"' + id + '\"><pre>Template ' + id + ' not found</pre></script>';
		  			return templateString;
		  		}

		  		if (file) {        
			        
			        //console.log(global.render);
			        var t = '/templates/' + tempTemplate;
			       	var data = {};
			        data['app'] = global.dipper;
			       	global.render.renderString(file, data, function(err, res) {

			       		//console.log(templateStr);

		  				templateString += '\n';
		  				templateString += '\t' + res;
		  				templateString += '\n';
		  				templateString += '</script>';
		  				templateString += '\n';
		  				//console.log(templateString);
		  				return templateString;
			       	});
		  		}
		  	});
    	}
	});
}

// -- Method to get a varable from Shared array
Dipper.prototype.getSharedVar = function(name) {

	var obj = this,
		ret = obj.shared[name] || '';
	if (ret != '') { ret = "'" + ret + "'"; }
	return ret;
}

Dipper.prototype.get_google_fonts = function(fonts) {

	let _ = require('underscore');

	if (fonts != undefined) {

		let parts = [],
			keys = Object.keys(fonts);
		_.each(keys, function(font) {

			let font_name = encodeURI(font),
				font_weight = fonts[font].join(',');
			parts.push(font_name + ':' + font_weight);
		});

		let params = parts.join('|'),
			ret = '//fonts.googleapis.com/css?family=' + params;

		return ret;
	} 
}

Dipper.prototype.includeEnvironment = function() {

	const obj = this;

	return `
		<script>
			var ENVIRONMENT = '${obj.shared.environment}';
			var API_URL = '${obj.options.api_url}';
			var VERSION = '${obj.shared.version}';
		</script>`;
}

// -- Helpers
Dipper.prototype.processCwd = function() {

	let cwd = process.cwd()
		.replace('/.scripts', '')
		.replace('/node_modules', '')
		.replace('/vanilla-jet', '');
	return cwd;
}

Dipper.prototype.openJsonFile = function(fileName) {

	let data = null;
	const fs = require('fs'),
		path = require('path'),
		filePath = path.join(this.processCwd(), '/' + fileName),
		exists = fs.existsSync(filePath);
	
	if (exists) {
		data = fs.readFileSync(filePath, 'utf8');
	}
	return JSON.parse(data);
}

module.exports = Dipper;
